package parser;

public class MainParser {
    public static void run() {
        System.out.println("=== Analizador Sintáctico (Parser) ===");
        System.out.println("Hello, world! 👋");
        System.out.println("Aquí irá el código del parser más adelante.");
    }
}
