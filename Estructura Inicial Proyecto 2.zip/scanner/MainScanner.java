package scanner;

import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java_cup.runtime.Symbol;
import static parser.sym.*; // requiere parser/sym.java (dummy o generado por CUP)

/**
 * MainScanner compatible con:
 * - Proyecto 2 (CUP): consume Symbol via next_token()
 * - ProyectoCompi2.java: expone run()
 * - Sin dependencias duras a TestFile/TokenCollector (usa reflexión si existen)
 */
public class MainScanner {

    /* ========= API invocada desde ProyectoCompi2.java ========= */
    public static void run() {
        runInteractive();
    }

    /* ========= Ejecutable directo opcional ========= */
    public static void main(String[] args) {
        if (args.length > 0) {
            for (String path : args) scanFile(path);
        } else {
            runInteractive();
        }
    }

    /* ========= Interactivo: usa TestFile si existe; si no, pide ruta ========= */
    public static void runInteractive() {
        Object[] testFiles = getTestFilesSafely();

        if (testFiles != null && testFiles.length > 0) {
            System.out.println("=== Pruebas del Analizador Léxico ===");
            for (int i = 0; i < testFiles.length; i++) {
                String label = getTestFileLabel(testFiles[i], i + 1);
                System.out.println(label);
            }
            System.out.print("Seleccione un número de prueba: ");

            java.util.Scanner in = new java.util.Scanner(System.in);
            int choice = -1;
            try { choice = in.nextInt(); in.nextLine(); } catch (Exception ignored) {}

            if (choice < 1 || choice > testFiles.length) {
                System.out.println("Opción inválida.");
                return;
            }
            String path = getTestFilePath(testFiles[choice - 1]);
            scanFile(path);
        } else {
            // Fallback sin TestFile: pedir una ruta
            System.out.println("No se encontró TestFile. Ingrese la ruta de un archivo a escanear:");
            java.util.Scanner in = new java.util.Scanner(System.in);
            String path = in.nextLine().trim();
            if (path.isEmpty()) {
                System.out.println("Ruta vacía. Saliendo.");
                return;
            }
            scanFile(path);
        }
    }

    /* ========= Núcleo: escanear un archivo con el lexer JFlex ========= */
    public static void scanFile(String path) {
        System.out.println("\n=== Escaneando: " + path + " ===");
        tryInvokeTokenCollector("clear");

        try (FileReader fr = new FileReader(path)) {
            // Usa el nombre completamente calificado para no chocar con java.util.Scanner
            scanner.Scanner lexer = new scanner.Scanner(fr);

            while (true) {
                Symbol tok = lexer.next_token(); // algunos templates devuelven null en EOF; otros un Symbol con sym==EOF
                if (tok == null || tok.sym == EOF) break;
                // Las reglas del .flex pueden estar llamando a TokenCollector.add(...) por su cuenta;
                // aquí no imprimimos por token para no duplicar salida.
            }

            System.out.println("\n--- TOKENS RECONOCIDOS ---");
            tryInvokeTokenCollector("printTokens");

            System.out.println("\n--- ERRORES LÉXICOS ---");
            tryInvokeTokenCollector("printErrors");

            System.out.println("\nFin del escaneo.\n");

        } catch (IOException ioe) {
            System.err.println("Error al leer el archivo: " + ioe.getMessage());
        } catch (Throwable t) {
            System.err.println("Error durante el escaneo: " + t.getClass().getSimpleName() + " - " + t.getMessage());
            t.printStackTrace(System.err);
        }
    }

    /* ========= Helpers para integraciones opcionales ========= */

    // Invoca métodos estáticos sin args en scanner.TokenCollector si existe (clear/printTokens/printErrors)
    private static void tryInvokeTokenCollector(String methodName) {
        try {
            Class<?> tc = Class.forName("scanner.TokenCollector");
            Method m = tc.getMethod(methodName);
            m.invoke(null);
        } catch (Throwable ignored) {
            // No existe TokenCollector o el método -> no hacemos nada
        }
    }

    // Intenta leer enum scanner.TestFile si existe; retorna null si no
    private static Object[] getTestFilesSafely() {
        try {
            Class<?> tf = Class.forName("scanner.TestFile");
            if (!tf.isEnum()) return null;
            Method values = tf.getMethod("values");
            return (Object[]) values.invoke(null);
        } catch (Throwable ignored) {
            return null;
        }
    }

    // Formatea la línea del menú usando getFileName()/getDescription() si existen
    private static String getTestFileLabel(Object enumConst, int index) {
        String fileName = safeStringCall(enumConst, "getFileName");
        String desc     = safeStringCall(enumConst, "getDescription");
        if (fileName == null) fileName = enumConst.toString();
        if (desc == null) desc = "";
        return String.format("%d) %s%s", index, fileName, desc.isEmpty() ? "" : " - " + desc);
    }

    // Obtiene la ruta usando getFilePath() si existe; si no, usa getFileName() como fallback
    private static String getTestFilePath(Object enumConst) {
        String path = safeStringCall(enumConst, "getFilePath");
        if (path == null) path = safeStringCall(enumConst, "getFileName");
        if (path == null) path = enumConst.toString();
        // Fallback: si es solo el nombre, prueba en scanner/test/
        if (!(new java.io.File(path)).exists()) {
            String alt = "scanner/test/" + path;
            if ((new java.io.File(alt)).exists()) return alt;
        }
        return path;
    }

    private static String safeStringCall(Object target, String method) {
        try {
            Method m = target.getClass().getMethod(method);
            Object r = m.invoke(target);
            return (r != null) ? r.toString() : null;
        } catch (Throwable ignored) {
            return null;
        }
    }
}
